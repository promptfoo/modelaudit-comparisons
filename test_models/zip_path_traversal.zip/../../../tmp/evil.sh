#!/bin/bash
echo pwned